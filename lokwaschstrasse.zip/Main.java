class Main {
    
    
    public static void main(String [] args){
        Lokwaschstrasse waschstrasse1=new Lokwaschstrasse();
        //Loks erzeugen
        Lok lokA=new Lok("BR111","Alfred");
        Lok lokB=new Lok("BR101","Berti");
        Lok lokC=new Lok("BR401","Carlo");
        Lok lokD=new Lok("BR121","David");
        Lok lokE=new Lok("BR103","Emma");
        Lok lokF=new Lok("BR403","Franz");
        Lok lokG=new Lok("BR481","Gustav");
        Lok lokH=new Lok("BR428","Hans");
        Lok lokI=new Lok("BR598","Ida");
        Lok lokJ=new Lok("BR001","Julia");
        //3 Loks einreihen
        System.out.println("LokA und LokB hinten einreihen");
        waschstrasse1.hintenAnstellen(lokA);
        waschstrasse1.hintenAnstellen(lokB);
        waschstrasse1.fahrerlisteAusgeben();
        //5 Loks rausfahren
        System.out.println("Fünf Loks vorne abfahren lassen");
        for (int i=0;i<5;i++){
            waschstrasse1.vorneAbfahren();
        }
        //weitere 4 Loks einreihen
        System.out.println("LokC bis LokF hinten anstellen");
        waschstrasse1.hintenAnstellen(lokC);
        waschstrasse1.hintenAnstellen(lokD);
        waschstrasse1.hintenAnstellen(lokE);
        waschstrasse1.hintenAnstellen(lokF);
        waschstrasse1.fahrerlisteAusgeben();
        System.out.println("Ein Lok vorne abfahren");
        waschstrasse1.vorneAbfahren();
        waschstrasse1.fahrerlisteAusgeben();
        System.out.println("LokG bis LokJ hinten anstellen");
        waschstrasse1.hintenAnstellen(lokG);
        waschstrasse1.hintenAnstellen(lokH);
        waschstrasse1.hintenAnstellen(lokI);
        waschstrasse1.hintenAnstellen(lokJ);
        waschstrasse1.fahrerlisteAusgeben();
    }
}

