class Lok {
    private String lokfahrer;
    private String baureihe;

    public Lok(String b, String f) {
        this.baureihe=b;
        this.lokfahrer=f;
    }
    public String getBaureihe(){
        return baureihe;
    }
    public String getlokfahrer(){
        return lokfahrer;
    }
}
