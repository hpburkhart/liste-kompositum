class Lokwaschstrasse {
    private int anzahlLoks;
    private Lok[] waschstrasse;

    public Lokwaschstrasse() {
        this.waschstrasse=new Lok[6];
        anzahlLoks=0;
    }

    public void hintenAnstellen(Lok t){
        if (anzahlLoks==6){
            System.out.println("Fehler: Kein Platz mehr frei!");
        }
        else {
            waschstrasse[anzahlLoks]=t;
            anzahlLoks=anzahlLoks+1;
        }
    }

    public Lok vorneAbfahren(){
        Lok ersteLok=null;
        if (anzahlLoks==0) {
            System.out.println("Fehler: Keine Lok in der Schlange!");
        }
        else {
            ersteLok=waschstrasse[0];
            for (int i=1;i<anzahlLoks;i++){
                waschstrasse[i-1]=waschstrasse[i];
            }
            waschstrasse[anzahlLoks-1]=null;
            anzahlLoks=anzahlLoks-1;
        }
        return ersteLok;
    }

    public void fahrerlisteAusgeben(){
        String ausgabe="";
        for (int i=0;i<anzahlLoks;i++){
            ausgabe=ausgabe+" |"+waschstrasse[i].getlokfahrer();
        }
        System.out.println(ausgabe);
    }
}

